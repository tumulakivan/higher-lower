import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginForm {
    private JPanel LoginForm;
    private JPanel MainPanel;
    private JPanel ButtonPanel;
    private JPanel InfoPanel;
    private JLabel lblUsername;
    private JTextField txtUsername;
    private JLabel lblPassword;
    private JButton btnLogIn;
    private JButton btnClear;
    private JPasswordField txtPassword;
    private int attempts = 3;

    public LoginForm() {
        btnLogIn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnLoginActionPerformed(e);
            }
        });
    }

    private void launchGame() {
        JFrame frame = new JFrame("HigherLowerGame");
        frame.setContentPane(new HigherLowerGame().HigherLowerGame);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {
        String user = txtUsername.getText();
        String password = String.valueOf(txtPassword.getPassword());
        JFrame loginFrame = (JFrame) SwingUtilities.getWindowAncestor(LoginForm);

        if(!user.equals("eeban") && !password.equals("eeyah")) {
            if(attempts == 0) {
                JOptionPane.showMessageDialog(null,"Maximum login attempts reached. Closing program.", "WARNING", JOptionPane.INFORMATION_MESSAGE);
                loginFrame.setVisible(false);
                loginFrame.dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password. " + String.valueOf(attempts) + " remaining.", "WARNING", JOptionPane.INFORMATION_MESSAGE);
            }

            attempts--;
        } else {
            launchGame();
            loginFrame.setVisible(false);
            loginFrame.dispose();
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("LoginForm");
        frame.setContentPane(new LoginForm().LoginForm);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
