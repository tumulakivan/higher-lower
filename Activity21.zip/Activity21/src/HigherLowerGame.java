import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class HigherLowerGame {
    JPanel HigherLowerGame;
    private JPanel pnlGameplay;
    private JPanel pnlMain;
    private JPanel pnlButtons;
    private JLabel lblGameplay;
    private JPanel pnlFirstNum;
    private JPanel pnlSecondNum;
    private JLabel lblFirstNum;
    private JLabel lblSecondNum;
    private JLabel prevFirstNum;
    private JButton btnLower;
    private JButton btnHigher;
    private JButton btnReset;
    private JPanel pnlReset;
    private JLabel prevSecondNum;
    private JPanel pnlInfo;
    private JPanel pnlScore;
    private JPanel pnlHealth;
    private JLabel lblScore;
    private JLabel lblScoreValue;
    private JLabel lblHealth;
    private JLabel lblHealthValue;
    private int rand_num1;
    private int rand_num2;
    private int score = 0;
    private int health = 3;

    public HigherLowerGame() {
        initializeValues();
        btnReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnResetActionPerformed(e);
            }
        });

        btnLower.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnLowerActionPerformed(e);
            }
        });

        btnHigher.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnHigherActionPerformed(e);
            }
        });
    }

    private void initializeValues() {
        generateRandom();
        lblHealthValue.setText(String.valueOf(health));
        lblScoreValue.setText(String.valueOf(score));
    }

    private void generateRandom() {
        Random rand1 = new Random();
        Random rand2 = new Random();
        rand_num1 = rand1.nextInt(100) + 1;
        rand_num2 = rand2.nextInt(100) + 1;
        prevFirstNum.setText(String.valueOf(rand_num1));
        prevSecondNum.setText("?");
    }

    public void setScore(int add_score) {
        score += add_score;
    }

    public void setHealth() {
        health -= 1;
        lblHealthValue.setText(String.valueOf(health));
    }

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {
        initializeValues();
    }

    private void btnLowerActionPerformed(java.awt.event.ActionEvent evt) {
        if(rand_num1 > rand_num2) {
            prevSecondNum.setText(String.valueOf(rand_num2));
            JOptionPane.showMessageDialog(null, "Correct!", "Result", JOptionPane.INFORMATION_MESSAGE);
            setScore(1);
            lblScoreValue.setText(String.valueOf(score));
            generateRandom();
        } else {
            JOptionPane.showMessageDialog(null, "Incorrect!", "Result", JOptionPane.INFORMATION_MESSAGE);
            setHealth();
        }
    }

    private void btnHigherActionPerformed(java.awt.event.ActionEvent evt) {
        if(rand_num1 < rand_num2) {
            prevSecondNum.setText(String.valueOf(rand_num2));
            JOptionPane.showMessageDialog(null, "Correct!", "Result", JOptionPane.INFORMATION_MESSAGE);
            setScore(1);
            lblScoreValue.setText(String.valueOf(score));
            generateRandom();
        } else {
            JOptionPane.showMessageDialog(null, "Incorrect!", "Result", JOptionPane.INFORMATION_MESSAGE);
            setHealth();
        }

        if(health < 1) {
            prevSecondNum.setText(String.valueOf(rand_num2));
            JFrame game = (JFrame) SwingUtilities.getWindowAncestor(HigherLowerGame);
            JOptionPane.showMessageDialog(null, "You ended the game with a score of " + String.valueOf(score) + ".", "Result", JOptionPane.INFORMATION_MESSAGE);
            game.setVisible(false);
            game.dispose();
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("HigherLowerGame");
        frame.setContentPane(new HigherLowerGame().HigherLowerGame);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
